
SET NOCOUNT ON


DECLARE
	@PracticeID INT,
	@DateType CHAR(1),
	@BeginDate DATETIME,
	@EndDate DATETIME,
	@ProviderID INT,
	@ServiceLocationID INT,
	@DepartmentID INT,
	@RevenueCategory INT,
	@BatchID VARCHAR(50),
	@ProcedureCodeStr varchar(8000)
SELECT 	
	@PracticeID = 65,
	@DateType = 'P',
	@BeginDate = '12/1/06',
	@EndDate = '12/27/06',
	@ProviderID = -1,
	@ServiceLocationID = -1,
	@DepartmentID = -1,
	@RevenueCategory = -1,
	@BatchID = NULL,
	@ProcedureCodeStr = NULL



	SELECT @ProcedureCodeStr = dbo.fn_ZeroLengthStringToNull( @ProcedureCodeStr )


DECLARE @StartRevCenter VARCHAR(16),
		@EndRevCenter VARCHAR(16),
		@RevenueName Varchar(128)

SELECT	@StartRevCenter = ProcedureCodeStartRange,
		@EndRevCenter = ProcedureCodeEndRange,
		@RevenueName = name
FROM ProcedureCodeRevenueCenterCategory 
WHERE @RevenueCategory = ProcedureCodeRevenueCenterCategoryID




select distinct
		c.ClaimID, 
		EP.EncounterProcedureID,
		ep.ProcedureCodeDictionaryID,
		ep.ProcedureModifier1,
		(ep.ServiceChargeAmount * ServiceUnitCount) as Charges,
		E.LocationID,
		E.DoctorID,
		E.PatientCaseID,
		E.PatientID,
		E.BatchID,
		E.PostingDate,
		CAST( NULL AS VARCHAR(16)) as ProcedureCode,
		CAST( NULL AS VARCHAR(300)) as ProcedureName,
		CAST( NULL AS VARCHAR(128)) as RevenueCategoryName
INTO #batch
from ClaimAccounting ca
		INNER JOIN Claim c ON c.PracticeID = @PracticeID AND ca.ClaimID = c.ClaimID
		INNER JOIN EncounterProcedure ep ON ep.PracticeID = @PracticeID AND c.EncounterProcedureID = ep.EncounterProcedureID
		INNER JOIN Encounter e on e.PracticeID = @PracticeID AND e.EncounterID = ep.EncounterID 
WHERE ca.PracticeID = @PracticeID
	AND (( @DateType = 'P' and ca.PostingDate between @BeginDate and @EndDate) OR (@DateType = 'S' and e.DateOfService BETWEEN @BeginDate and @EndDate))
	AND ( ClaimTransactionTypeCode = 'PAY')
	AND ( @ProviderID = -1 or @ProviderID =e.DoctorID )
	AND ( @ServiceLocationID = -1 OR @ServiceLocationID = e.LocationID )
	
	



UPDATE b
SET RevenueCategoryName = Name,
	ProcedureCode = PCD.ProcedureCode,
	ProcedureName = ISNULL( PCD.LocalName, OfficialName)
FROM	#batch AS b
	INNER JOIN ProcedureCodeDictionary pcd ON pcd.ProcedureCodeDictionaryID = b.ProcedureCodeDictionaryID 
	LEFT JOIN ReportDataProvider_vProcedureCodeRevenueCenterCategory rev ON dbo.fn_ParseProcedureCode_Alpha( pcd.ProcedureCode ) = AlphaCode
		AND dbo.fn_ParseProcedureCode_Numeric( pcd.ProcedureCode ) between RangeStart and RangeEnd

		
IF @RevenueCategory <> -1
	BEGIN
		DELETE #batch
		WHERE @RevenueName <> ISNULL(RevenueCategoryName, 'Other')
	END


SELECT  ct.ClaimID, 
		b.PatientCaseID,
		b.PostingDate,
		Charges,
		Amount,
		RTRIM(ISNULL(d.FirstName + ' ', '') + ISNULL(dbo.fn_ZeroLengthStringToNull(d.MiddleName) + ' ', '')) + ISNULL(' ' + d.LastName, '') + ISNULL(', ' + d.Degree, '') as ProviderName, 
		ISNULL(dept.Name, 'Other') as DepartmentName,
		ISNULL(sl.Name, 'Other') as ServiceLocationName,
		ct.ClaimTransactionID,
		cast(NULL as INT) as PrimaryPayerID,
		CAST( (Case WHEN p.PayerTypeCode = 'P' THEN 'Patient' ELSE NULL END) as Varchar(128)) AS PayerType,
		P.PayerID,
		b.ProcedureCode,
		b.ProcedureName,
		b.RevenueCategoryName,
		b.ProcedureModifier1
INTO #ep2
FROM	#Batch b  
		INNER JOIN  ClaimAccounting AS ct on ct.PracticeID = @PracticeID AND ct.ClaimID = b.ClaimID 
		LEFT OUTER JOIN ServiceLocation AS sl ON sl.ServiceLocationID = b.LocationID AND SL.PracticeID = @PracticeID 
		INNER JOIN Doctor AS d ON  b.DoctorID = d.DoctorID AND d.PracticeID =@PracticeID
		LEFT OUTER JOIN Department AS dept ON dept.DepartmentID = d.DepartmentID
		INNER JOIN PaymentClaimTransaction pct ON pct.PracticeID = ct.PracticeID AND ct.ClaimID = pct.ClaimID AND ct.ClaimTransactionID = pct.ClaimTransactionID
		INNER JOIN Payment p on p.PracticeID = @PracticeID AND  p.PaymentID = pct.PaymentID
WHERE 	ct.PracticeID = @PracticeID 
		AND ct.ClaimTransactionTypeCode = 'PAY' 
		AND ( @DepartmentID = -1 or @DepartmentID = dept.DepartmentID )
		AND ( @BatchID is null or rtrim(@BatchID) = rtrim(p.BatchID) OR rtrim(@BatchID) = rtrim(b.BatchID)  )



Update ep
SET PrimaryPayerID = ip.InsuranceCompanyPlanID
FROM #ep2 ep 
	INNER JOIN InsurancePolicy ip ON ip.PatientCaseID = ep.PatientCaseID AND ip.Precedence = dbo.fn_InsuranceDataProvider_GetMinInsurancePolicyPrecedence( ep.PatientCaseID, PostingDate, 0)
WHERE PayerType IS NULL


UPDATE #ep2
SET PayerType =  Case when  PayerID = PrimaryPayerID THEN 'Primary' ELSE 'Secondary' END
WHERE PayerType IS NULL



SELECT 
	ProcedureCode,
	ProcedureName,
	ProcedureModifier1,
	Count(Distinct ClaimID) as numOfProcedures,
	SumCharges = (SELECT SUM(Amount) FROM ClaimAccounting ca INNER JOIN (Select distinct ProcedureCode, ProcedureModifier1, claimID FROM #ep2) as e2 ON ca.ClaimID = e2.ClaimID AND ca.ClaimTransactionTypeCode = 'CST' WHERE e2.ProcedureCode = e.ProcedureCode AND ISNULL(e2.ProcedureModifier1, '') = ISNULL(e.ProcedureModifier1, '')),
	AvgCharges = (SELECT AVG(Amount) FROM ClaimAccounting ca INNER JOIN (Select distinct ProcedureCode, ProcedureModifier1, claimID FROM #ep2) as e2 ON ca.ClaimID = e2.ClaimID AND ca.ClaimTransactionTypeCode = 'CST' WHERE e2.ProcedureCode = e.ProcedureCode AND ISNULL(e2.ProcedureModifier1, '') = ISNULL(e.ProcedureModifier1, '')),
	AvgPrimaryPayment = (Select Avg( AMOUNT ) FROM #ep2  e2 WHERE PayerType = 'PRIMARY' AND e2.ProcedureCode = e.ProcedureCode AND ISNULL(e2.ProcedureModifier1, '') = ISNULL(e.ProcedureModifier1, '') ),
	AvgSecondaryPayment  = (Select Avg( AMOUNT ) FROM #ep2  e2 WHERE PayerType = 'SECONDARY' AND e2.ProcedureCode = e.ProcedureCode AND ISNULL(e2.ProcedureModifier1, '') = ISNULL(e.ProcedureModifier1, '') ),
	AvgPatientPayment = (Select Avg( AMOUNT ) FROM #ep2  e2 WHERE PayerType = 'PATIENT' AND e2.ProcedureCode = e.ProcedureCode AND ISNULL(e2.ProcedureModifier1, '') = ISNULL(e.ProcedureModifier1, '') ),
	AvgTotalPayment = AVG( Amount )
FROM #ep2 e
GROUP BY 
	ProcedureCode,
	ProcedureName,
	ProcedureModifier1
order by ProcedureCode



return
DROP TABLE #ep2, #batch


select *
from #ep2
where ProcedureCode = '62319' AND 

select ca.*, p.PayerID, P.PayerTypeCode
from ClaimAccounting ca
	INNER JOIN PaymentClaimTransaction pct ON pct.ClaimTransactionID = ca.ClaimTransactionID
	INNER JOIN Payment p ON p.PaymentID = pct.PaymentID
where ca.claimID = 632313-- 303527

select *
from ClaimAccounting_Assignments
where ClaimID = 632313